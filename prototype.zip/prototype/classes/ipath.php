<?php
	//画像のパス
	define('ipath', '/dulcis/ref/img/');
?>