<?php
	//セッションの破棄
	$_SESSION = array();
	session_destroy();
?>