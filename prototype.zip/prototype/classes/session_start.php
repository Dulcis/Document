<?php
	//セッションの開始
	session_start();
?>