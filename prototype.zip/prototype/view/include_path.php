<?php
	//インクルードのパス設定
	ini_set('include_path', '/xampp/htdocs/dulcis/classes/');
?>